﻿using AutoMapper;

namespace SSISApp.WebApi.Profiles
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {                
        }
    }
}
