﻿namespace SSISApp.WebApi.Models
{
    public class TViewModel
    {
    }
}
